//
//  TPConstants.h
//
//  Created by Trialpay Inc.
//  Copyright (c) 2013 TrialPay, Inc. All Rights Reserved.
//

// Disable exceptions unless defined
#ifndef __TRIALPAY_USE_EXCEPTIONS
    #define __TRIALPAY_USE_EXCEPTIONS 1
#endif
