//
//  TpVideoEndcapViewController.h
//
//  Created by Trialpay Inc.
//  Copyright (c) 2014 TrialPay, Inc. All Rights Reserved.
//

#import <UIKit/UIKit.h>

@interface TpVideoEndcapViewController : UIViewController

- (void)hideNativeExitButton;

@property (assign, nonatomic) BOOL shouldShowExitButton;

@end
