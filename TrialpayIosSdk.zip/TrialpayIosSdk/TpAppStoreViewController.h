//
//  TpAppStoreViewController.h
//
//  Created by Trialpay Inc.
//  Copyright (c) 2014 TrialPay, Inc. All Rights Reserved.
//

#import <StoreKit/StoreKit.h>

@interface TpAppStoreViewController : SKStoreProductViewController
@end
